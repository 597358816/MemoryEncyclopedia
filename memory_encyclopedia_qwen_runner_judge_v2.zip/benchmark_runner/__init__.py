"""MemoryEncyclopedia benchmark runner."""
