# MemoryEncyclopedia LLM judge overlay

Copy the `benchmark_runner/` folder into the root of `MemoryEncyclopedia`.

It adds a reusable local LLM-as-Judge based on:

```text
/vepfs-mlp2/c20250203/250602012/models/Qwen/Qwen3-14B/
```

Start with:

```bash
python -m benchmark_runner.llm_judge.check_env
python -m benchmark_runner.llm_judge.judge \
  --input benchmark_runner/llm_judge/examples/judge_input.jsonl \
  --output /tmp/judge_test.jsonl \
  --id-key item_id \
  --problem-key problem \
  --candidate-key candidate \
  --reference-key reference
```
